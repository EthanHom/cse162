package ethanhom.cse_162.fragment;

//import androidx.appcompat.app.AppCompatActivity;
//
//import android.app.FragmentManager;
//import android.os.Bundle;
import android.os.Parcelable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;   // AndroidX FragmentManager
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements HeadlineFragment.OnHeadLineSelectedListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        phone is in portrait mode
        boolean twoPane = getResources().getBoolean(R.bool.two_pane);  // values vs values-land [web:150][web:151]
        FragmentManager fm = getSupportFragmentManager();
//        if (findViewById(R.id.layout_default) != null) {
        if (twoPane) {
//            FragmentManager manager = this.getSupportFragmentManager();
            fm.beginTransaction()
//            manager.beginTransaction()
                    .show(fm.findFragmentById(R.id.headlines_fragment))
                    .show(fm.findFragmentById(R.id.news_fragment))
                    .commit();
        }
        else {

            fm.beginTransaction()
                    .show(fm.findFragmentById(R.id.headlines_fragment))
                    .hide(fm.findFragmentById(R.id.news_fragment))
                    .commit();
        }
    }

    public void onArticleSelected(int position) {

//        if (findViewById(R.id.layout_default) != null) {
//            FragmentManager manager = this.getSupportFragmentManager();
//            manager.beginTransaction()
//                    .hide(manager.findFragmentById(R.id.headlines_fragment))
//                    .show(manager.findFragmentById(R.id.news_fragment))
//                    .addToBackStack(null)
//                    .commit();
//        }
//
//        NewsFragment newsFragment = (NewsFragment) getSupportFragmentManager().findFragmentById(R.id.news_fragment);
//        newsFragment.updateArticleView(position);


        FragmentManager fm = getSupportFragmentManager();               // AndroidX fragment manager [web:38]

        NewsFragment news = (NewsFragment) fm.findFragmentById(R.id.news_fragment);
        if (news != null) {
            news.updateArticleView(position);                           // Update detail pane [web:38]
        }

        boolean twoPane = getResources().getBoolean(R.bool.two_pane);   // Decide single vs two pane [web:151]
        if (!getResources().getBoolean(R.bool.two_pane)) {
            fm.beginTransaction()
                    .hide(fm.findFragmentById(R.id.headlines_fragment))
                    .show(fm.findFragmentById(R.id.news_fragment))
                    .addToBackStack(null)
                    .commit();
        }
    }

}
