package ethanhom.cse_162.fragment;

public class Ipsum {
    static String[] Headlines = {
            "Article One",
            "Article Two"
    };

    static String[] Articles = {
            "Article One Random Text",
            "Article Two Random Text"
    };
}
